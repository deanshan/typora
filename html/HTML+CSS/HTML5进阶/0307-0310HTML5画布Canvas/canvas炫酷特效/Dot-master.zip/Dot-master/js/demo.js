Dot("dot", {
    cW:1400,
    cH:700
});